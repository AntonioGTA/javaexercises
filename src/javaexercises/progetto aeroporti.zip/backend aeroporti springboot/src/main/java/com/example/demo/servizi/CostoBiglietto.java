package com.example.demo.servizi;

import java.util.Date;

import org.springframework.stereotype.Service;

@Service
public class CostoBiglietto {

    private static final double PREZZO_BASE = 100.0;
    private static final int POSTI_TOTALI = 50;
    private static final int NUMERO_SCAGLIONI = 5;
    private static final double AUMENTO_PERCENTUALE = 0.10;
    private static final double AUMENTO_FESTIVITA = 0.10;

    public double calcolaCostoBiglietto(int postiPrenotati, Date dataPrenotazione) {
        double costoBase = PREZZO_BASE;
        int postiPerScaglione = POSTI_TOTALI / NUMERO_SCAGLIONI;

        // Calcolo dello scaglione
        int scaglione = Math.min(postiPrenotati / postiPerScaglione, NUMERO_SCAGLIONI - 1);

        // Applica l'aumento percentuale per ogni scaglione superato
        for (int i = 0; i < scaglione; i++) {
            costoBase *= (1 + AUMENTO_PERCENTUALE);
        }

        // Verifica se la data di prenotazione è una festività (ad esempio, domenica)
        boolean isFestivita = isFestivita(dataPrenotazione);

        // Applica l'aumento percentuale per la festività
        if (isFestivita) {
            costoBase *= (1 + AUMENTO_FESTIVITA);
        }

        return costoBase;
    }

    private boolean isFestivita(Date data) {
        // Implementa la logica per verificare se la data è una festività
        // Ad esempio, verifica se è domenica o un giorno di Natale
        // Restituisce true se è festività, false altrimenti
        return false; // Implementa la logica reale qui
    }
}

