package com.example.demo.controller;

import com.example.demo.modello.Prenotazione;
import com.example.demo.servizi.PrenotazioniService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/prenotazioni")
public class PrenotazioniController {

    @Autowired
    private PrenotazioniService prenotazioniService;

    @GetMapping
    public List<Prenotazione> getPrenotazioni() {
        return prenotazioniService.getPrenotazioni();
    }

    @GetMapping("/{id}")
    public Prenotazione getPrenotazioneById(@PathVariable Long id) {
        return prenotazioniService.getPrenotazioneById(id);
    }

    @PostMapping
    public Prenotazione addPrenotazione(@RequestBody Prenotazione prenotazione) {
        return prenotazioniService.addPrenotazione(prenotazione);
    }

    @PutMapping("/{id}")
    public Prenotazione updatePrenotazione(@PathVariable Long id, @RequestBody Prenotazione prenotazione) {
        return prenotazioniService.updatePrenotazione(id, prenotazione);
    }

    @DeleteMapping("/{id}")
    public String deletePrenotazione(@PathVariable Long id) {
        prenotazioniService.deletePrenotazione(id);
        return "Prenotazione eliminata";
    }
}
