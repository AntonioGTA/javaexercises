package com.example.demo.modello;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Clienti {

    @Id
    @Column(name = "idcliente" )
    private Long idcliente;

    @Column(name = "nome" )
    private String nome;

    @Column(name = "indirizzo" )
    private String indirizzo;

    @Column(name = "numerotelefono" )
    private String numerotelefono;

    @Column(name = "eta" )
    private int eta;

    public Long getIdcliente() {
        return idcliente;
    }

    public void setIdcliente(Long idcliente) {
        this.idcliente = idcliente;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getIndirizzo() {
        return indirizzo;
    }

    public void setIndirizzo(String indirizzo) {
        this.indirizzo = indirizzo;
    }

    public String getNumtelefono() {
        return numerotelefono;
    }

    public void setNumtelefono(String numtelefono) {
        this.numerotelefono = numtelefono;
    }

    public int getEta() {
        return eta;
    }

    public void setEta(int eta) {
        this.eta = eta;
    }


}
