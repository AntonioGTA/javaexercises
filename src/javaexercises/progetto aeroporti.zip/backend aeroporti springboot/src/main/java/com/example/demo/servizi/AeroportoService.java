package com.example.demo.service;

import com.example.demo.modello.Aeroporti;
import com.example.demo.repository.AeroportoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AeroportoService {

    private final AeroportoRepository aeroportoRepository;

    @Autowired
    public AeroportoService(AeroportoRepository aeroportoRepository) {
        this.aeroportoRepository = aeroportoRepository;
    }

    public List<Aeroporti> getAllAeroporti() {
        return aeroportoRepository.findAll();
    }

    public Aeroporti getAeroportoById(Long id) {
        Optional<Aeroporti> aeroportoOptional = aeroportoRepository.findById(id);
        return aeroportoOptional.orElse(null);
    }

    public Aeroporti createAeroporto(Aeroporti aeroporto) {
        return aeroportoRepository.save(aeroporto);
    }

    public Aeroporti updateAeroporto(Long id, Aeroporti aeroporto) {
        aeroporto.setIdAeroporto(id);
        return aeroportoRepository.save(aeroporto);
    }

    public void deleteAeroporto(Long id) {
        aeroportoRepository.deleteById(id);
    }
}
