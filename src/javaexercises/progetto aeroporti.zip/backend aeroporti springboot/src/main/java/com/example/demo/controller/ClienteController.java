package com.example.demo.controller;

import com.example.demo.modello.Clienti;
import com.example.demo.servizi.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/clienti")
public class ClienteController {

    @Autowired
    private ClienteService clienteService;

    @GetMapping
    public List<Clienti> getClienti() {
        return clienteService.getClienti();
    }

    @GetMapping("/{id}")
    public Clienti getClienteById(@PathVariable Long id) {
        return clienteService.getClienteById(id);
    }

    @PostMapping
    public Clienti addCliente(@RequestBody Clienti cliente) {
        return clienteService.addCliente(cliente);
    }

    @PutMapping("/{id}")
    public Clienti updateCliente(@PathVariable Long id, @RequestBody Clienti cliente) {
        return clienteService.updateCliente(id, cliente);
    }

    @DeleteMapping("/{id}")
    public String deleteCliente(@PathVariable Long id) {
        clienteService.deleteCliente(id);
        return "Cliente eliminato";
    }
}
