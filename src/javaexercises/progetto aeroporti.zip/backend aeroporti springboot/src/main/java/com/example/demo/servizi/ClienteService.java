package com.example.demo.servizi;

import com.example.demo.modello.Clienti;
import com.example.demo.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    public List<Clienti> getClienti() {
        return clienteRepository.findAll();
    }

    public Clienti getClienteById(Long id) {
        Optional<Clienti> clienteOptional = clienteRepository.findById(id);
        return clienteOptional.orElse(null);
    }

    public Clienti addCliente(Clienti cliente) {
        return clienteRepository.save(cliente);
    }

    public Clienti updateCliente(Long id, Clienti cliente) {
        cliente.setIdcliente(id);
        return clienteRepository.save(cliente);
    }

    public void deleteCliente(Long id) {
        clienteRepository.deleteById(id);
    }
}
