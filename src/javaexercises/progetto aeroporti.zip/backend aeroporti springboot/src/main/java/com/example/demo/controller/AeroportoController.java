package com.example.demo.controller;

import com.example.demo.modello.Aeroporti;
import com.example.demo.service.AeroportoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/aeroporti")
public class AeroportoController {

    private final AeroportoService aeroportoService;

    @Autowired
    public AeroportoController(AeroportoService aeroportoService) {
        this.aeroportoService = aeroportoService;
    }

    @GetMapping("/visualizza")
    public List<Aeroporti> getAllAeroporti() {
        return aeroportoService.getAllAeroporti();
    }

    @GetMapping("/{id}")
    public Aeroporti getAeroportoById(@PathVariable Long id) {
        return aeroportoService.getAeroportoById(id);
    }

    @PostMapping("/aggiungi")
    public Aeroporti createAeroporto(@RequestBody Aeroporti aeroporto) {
        return aeroportoService.createAeroporto(aeroporto);
    }

    @PutMapping("/aggiorna/{id}")
    public Aeroporti updateAeroporto(@PathVariable Long id, @RequestBody Aeroporti aeroporto) {
        return aeroportoService.updateAeroporto(id, aeroporto);
    }

    @DeleteMapping("/{id}")
    public void deleteAeroporto(@PathVariable Long id) {
        aeroportoService.deleteAeroporto(id);
    }
}
