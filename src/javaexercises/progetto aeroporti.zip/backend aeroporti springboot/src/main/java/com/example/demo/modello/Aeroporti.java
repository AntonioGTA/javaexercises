package com.example.demo.modello;

import javax.persistence.*;

@Entity
@Table(name = "AEROPORTI")
public class Aeroporti {
    @Id
    @Column(name = "IDAEROPORTO")
    private Long idAeroporto;

    @Column(name = "CITTA")
    private String citta;

    @Column(name = "NAZIONE")
    private String nazione;

    @Column(name = "NUMPISTE")
    private Integer numPiste;

    @Column(name = "NOMEAEROPORTO")
    private String nomeAeroporto;

    public Aeroporti() {
    }

    public Long getIdAeroporto() {
        return this.idAeroporto;
    }

    public void setIdAeroporto(Long idAeroporto) {
        this.idAeroporto = idAeroporto;
    }

    public String getCitta() {
        return this.citta;
    }

    public void setCitta(String citta) {
        this.citta = citta;
    }

    public String getNazione() {
        return this.nazione;
    }

    public void setNazione(String nazione) {
        this.nazione = nazione;
    }

    public Integer getNumPiste() {
        return this.numPiste;
    }

    public void setNumPiste(Integer numPiste) {
        this.numPiste = numPiste;
    }

    public String getNomeAeroporto() {
        return this.nomeAeroporto;
    }

    public void setNomeAeroporto(String nomeAeroporto) {
        this.nomeAeroporto = nomeAeroporto;
    }
}
