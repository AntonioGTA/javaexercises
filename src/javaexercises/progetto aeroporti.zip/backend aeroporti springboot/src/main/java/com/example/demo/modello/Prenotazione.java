package com.example.demo.modello;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Date;

@Entity
public class Prenotazione {

    @Id
    @Column(name = "idprenotazione")
    private Long idprenotazione;

    @Column(name = "numerovolo")
    private Long numerovolo;

    @Column(name = "codicecliente")
    private Long codicecliente;

    @Column(name = "dataprenotazione")
    private Date dataprenotazione;

    @Column(name = "dataviaggio")
    private Date dataviaggio;

    @Column(name = "costofatturato")
    private Long costofatturato;

    public Long getIdprenotazione() {
        return idprenotazione;
    }

    public void setIdprenotazione(Long idprenotazione) {
        this.idprenotazione = idprenotazione;
    }

    public Long getCodicecliente() {
        return codicecliente;
    }

    public void setCodicecliente(Long codicecliente) {
        this.codicecliente = codicecliente;
    }

    public Long getNumerovolo() {
        return numerovolo;
    }

    public void setNumerovolo(Long numerovolo) {
        this.numerovolo = numerovolo;
    }

    public Date getDataprenotazione() {
        return dataprenotazione;
    }

    public void setDataprenotazione(Date dataprenotazione) {
        this.dataprenotazione = dataprenotazione;
    }

    public Date getDataviaggio() {
        return dataviaggio;
    }

    public void setDataviaggio(Date dataviaggio) {
        this.dataviaggio = dataviaggio;
    }

    public Long getCostofatturato() {
        return costofatturato;
    }

    public void setCostofatturato(Long costofatturato) {
        this.costofatturato = costofatturato;
    }
}
