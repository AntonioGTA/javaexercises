package com.example.demo.modello;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Compagnieaeree {

    @Id
    @Column(name = "idcompagnia")
    private long idcompagnia;

    @Column(name = "nomecompagnia")
    private String nomecompagnia;

    @Column(name = "sede")
    private String sede;

    // Costruttore vuoto
    public Compagnieaeree() {
    }

    // Costruttore con parametri
    public Compagnieaeree(long idcompagnia, String nomecompagnia, String sede) {
        this.idcompagnia = idcompagnia;
        this.nomecompagnia = nomecompagnia;
        this.sede = sede;
    }

    public long getIdcompagnia() {
        return idcompagnia;
    }

    public void setIdcompagnia(long idcompagnia) {
        this.idcompagnia = idcompagnia;
    }

    public String getNomeCompagnia() {
        return nomecompagnia;
    }

    public void setNomeCompagnia(String nomeCompagnia) {
        this.nomecompagnia = nomeCompagnia;
    }

    public String getSede() {
        return sede;
    }

    public void setSede(String sede) {
        this.sede = sede;
    }
}
