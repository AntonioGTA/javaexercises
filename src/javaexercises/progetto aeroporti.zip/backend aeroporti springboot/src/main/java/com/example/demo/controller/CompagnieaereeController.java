package com.example.demo.controller;

import com.example.demo.modello.Compagnieaeree;
import com.example.demo.servizi.CompagnieaereeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/compagnieaeree")
public class CompagnieaereeController {

    @Autowired
    private CompagnieaereeService compagnieaereeService;

    @GetMapping
    public List<Compagnieaeree> getCompagnieaeree() {
        return compagnieaereeService.getCompagnieaeree();
    }

    @GetMapping("/{id}")
    public Compagnieaeree getCompagniaById(@PathVariable long id) {
        return compagnieaereeService.getCompagniaById(id);
    }

    @PostMapping
    public Compagnieaeree addCompagnia(@RequestBody Compagnieaeree compagnia) {
        return compagnieaereeService.addCompagnia(compagnia);
    }

    @PutMapping("/{id}")
    public Compagnieaeree updateCompagnia(@PathVariable long id, @RequestBody Compagnieaeree compagnia) {
        return compagnieaereeService.updateCompagnia(id, compagnia);
    }

    @DeleteMapping("/{id}")
    public String deleteCompagnia(@PathVariable long id) {
        compagnieaereeService.deleteCompagnia(id);
        return "Compagnia aerea eliminata";
    }
}
