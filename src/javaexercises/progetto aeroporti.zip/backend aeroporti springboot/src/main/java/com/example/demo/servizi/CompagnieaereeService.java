package com.example.demo.servizi;

import com.example.demo.modello.Compagnieaeree;
import com.example.demo.repository.CompagnieaereeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CompagnieaereeService {

    @Autowired
    private CompagnieaereeRepository compagnieaereeRepository;

    public List<Compagnieaeree> getCompagnieaeree() {
        return compagnieaereeRepository.findAll();
    }

    public Compagnieaeree getCompagniaById(long id) {
        Optional<Compagnieaeree> compagniaOptional = compagnieaereeRepository.findById(id);
        return compagniaOptional.orElse(null);
    }

    public Compagnieaeree addCompagnia(Compagnieaeree compagnia) {
        return compagnieaereeRepository.save(compagnia);
    }

    public Compagnieaeree updateCompagnia(long id, Compagnieaeree compagnia) {
        compagnia.setIdcompagnia(id);
        return compagnieaereeRepository.save(compagnia);
    }

    public void deleteCompagnia(long id) {
        compagnieaereeRepository.deleteById(id);
    }
}
