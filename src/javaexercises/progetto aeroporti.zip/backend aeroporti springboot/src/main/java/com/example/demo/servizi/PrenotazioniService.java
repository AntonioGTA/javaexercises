package com.example.demo.servizi;

import com.example.demo.modello.Prenotazione;
import com.example.demo.repository.PrenotazioniRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PrenotazioniService {

    @Autowired
    private PrenotazioniRepository prenotazioniRepository;

    public List<Prenotazione> getPrenotazioni() {
        return prenotazioniRepository.findAll();
    }

    public Prenotazione getPrenotazioneById(Long id) {
        Optional<Prenotazione> prenotazioneOptional = prenotazioniRepository.findById(id);
        return prenotazioneOptional.orElse(null);
    }

    public Prenotazione addPrenotazione(Prenotazione prenotazione) {
        return prenotazioniRepository.save(prenotazione);
    }

    public Prenotazione updatePrenotazione(Long id, Prenotazione prenotazione) {
        prenotazione.setIdprenotazione(id);
        return prenotazioniRepository.save(prenotazione);
    }

    public void deletePrenotazione(Long id) {
        prenotazioniRepository.deleteById(id);
    }
}
