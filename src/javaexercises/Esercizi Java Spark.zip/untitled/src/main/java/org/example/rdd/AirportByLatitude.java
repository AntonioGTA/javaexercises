package org.example.rdd;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

public class AirportByLatitude {

    public static void main(String[] args) {
        SparkConf conf = new SparkConf().setAppName("AirportByLatitude").setMaster("local[*]");
        JavaSparkContext sc = new JavaSparkContext(conf);

        JavaRDD<String> airportsData = sc.textFile("C:\\Users\\bb\\Downloads\\ESERCIZI\\untitled\\in\\airports.text");

        JavaRDD<String> airportsByLatitude = airportsData.filter(line -> {
            // Controllo sulla lunghezza della riga
            if (line == null || line.isEmpty()) {
                return false;
            }
            String[] columns = line.split(",");
            // Controllo sulla lunghezza delle colonne
            if (columns.length < 7) {
                return false;
            }
            try {
                double latitude = Double.parseDouble(columns[6]);
                // Filtraggio per latitudine maggiore di 40.0
                return latitude > 40.0;
            } catch (NumberFormatException e) {
                // Gestione del parsing fallito
                return false;
            }
        });

        JavaRDD<String> result = airportsByLatitude.map(line -> {
            String[] columns = line.split(",");
            // Controllo sulla lunghezza delle colonne
            if (columns.length < 7) {
                return "";
            }
            String airportName = columns[1];
            double latitude = Double.parseDouble(columns[6]);

            return "\"" + airportName + "\", " + latitude;
        });

        result.saveAsTextFile("C:\\Users\\bb\\Downloads\\ESERCIZI\\untitled\\out\\airports_by_latitude.text");

        sc.close();
    }
}
