package org.example.rdd;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import scala.Tuple2;

public class SameHostsProblem {

    public static void main(String[] args) {
        JavaSparkContext sc = new JavaSparkContext("local[*]", "SameHostsProblem");


        String inputPath1 = "C:\\Users\\bb\\Downloads\\ESERCIZI\\untitled\\in\\nasa_19950701.tsv";
        String inputPath2 = "C:\\Users\\bb\\Downloads\\ESERCIZI\\untitled\\in\\nasa_19950801.tsv";


        JavaRDD<String> logLines1 = sc.textFile(inputPath1).filter(line -> !line.startsWith("host"));
        JavaRDD<String> logLines2 = sc.textFile(inputPath2).filter(line -> !line.startsWith("host"));


        JavaPairRDD<String, Integer> hosts1 = logLines1.mapToPair(line -> new Tuple2<>(line.split("\t")[0], 1));
        JavaPairRDD<String, Integer> hosts2 = logLines2.mapToPair(line -> new Tuple2<>(line.split("\t")[0], 1));

        JavaPairRDD<String, Tuple2<Integer, Integer>> sameHosts = hosts1.join(hosts2);


        sameHosts.keys().saveAsTextFile("out/nasa_logs_same_hosts.text");


        sc.stop();
    }
}
