package org.example.rdd;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import scala.Tuple2;

public class AirportNotInUsa {
    public static void main(String[] args) {
        JavaSparkContext sc = new JavaSparkContext("local[*]", "AirportNotInUsa");

        JavaRDD<String> lines = sc.textFile("in/airports.text");

        JavaPairRDD<String, String> aeroportiPerPaese = lines.mapToPair(line -> {
            String[] colonne = line.split(",");
            String nomeAeroporto = colonne[1];
            String paese = colonne[3];
            return new Tuple2<>(nomeAeroporto, paese);
        });

        JavaPairRDD<String, String> aeroportiNonNegliStatiUniti = aeroportiPerPaese.filter(pair -> !pair._2().equals("United States"));

        aeroportiNonNegliStatiUniti.saveAsTextFile("out//airports_not_in_usa_pair_rdd.text");

        sc.close();
    }
}

