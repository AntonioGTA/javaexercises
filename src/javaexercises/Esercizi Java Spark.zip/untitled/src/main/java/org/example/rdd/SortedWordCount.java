package org.example.rdd;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import scala.Tuple2;

import java.util.Arrays;

public class SortedWordCount {
    public static void main(String[] args) {

        SparkSession spark = SparkSession.builder()
                .appName("SortedWordCount")
                .master("local[*]")
                .getOrCreate();
        JavaSparkContext sc = new JavaSparkContext(spark.sparkContext());


        JavaRDD<String> lines = sc.textFile("C:\\Users\\bb\\Downloads\\ESERCIZI\\untitled\\in\\word_count.text");


        JavaRDD<String> words = lines.flatMap(line -> Arrays.asList(line.split(" ")).iterator());
        JavaPairRDD<String, Integer> wordCounts = words.mapToPair(word -> new Tuple2<>(word, 1));


        JavaPairRDD<String, Integer> wordCountsSorted = wordCounts.reduceByKey(Integer::sum)
                .mapToPair(tuple -> new Tuple2<>(tuple._2, tuple._1)) // Inverti la tupla per ordinare per valore
                .sortByKey(false) // Ordina per valore in ordine decrescente
                .mapToPair(tuple -> new Tuple2<>(tuple._2, tuple._1)); // Ri-inverti la tupla


        wordCountsSorted.foreach(tuple -> System.out.println(tuple._1 + " : " + tuple._2));


        spark.stop();
    }
}
