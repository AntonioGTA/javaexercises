package org.example.rdd;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import scala.Tuple2;

public class AverageHouse {
    public static void main(String[] args) {
        SparkSession spark = SparkSession.builder()
                .appName("AverageHouse")
                .master("local[*]")
                .getOrCreate();
        JavaSparkContext sc = new JavaSparkContext(spark.sparkContext());

        JavaRDD<String> lines = sc.textFile("in/RealEstate.csv");

        String header = lines.first();
        JavaRDD<String> data = lines.filter(line -> !line.equals(header));

        JavaRDD<String> bedroomPrice = data.map(line -> {
            String[] parts = line.split(",");
            return parts[3] + "," + parts[2];
        });

        JavaRDD<String> averagePriceByBedrooms = bedroomPrice.mapToPair(bedroomPriceStr -> {
                    String[] parts = bedroomPriceStr.split(",");
                    int bedrooms = Integer.parseInt(parts[0]);
                    double price = Double.parseDouble(parts[1]);
                    return new Tuple2<>(bedrooms, new Tuple2<>(price, 1));
                }).reduceByKey((tuple1, tuple2) -> new Tuple2<>(tuple1._1 + tuple2._1, tuple1._2 + tuple2._2))
                .mapValues(tuple -> tuple._1 / tuple._2)
                .map(tuple -> "(" + tuple._1 + ", " + tuple._2 + ")");

        averagePriceByBedrooms.collect().forEach(System.out::println);

        spark.stop();
    }
}
