package org.example.rdd;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import java.util.Arrays;
import java.util.List;

public class TakeJob {

    public static void main(String[] args) {
        // Creare una configurazione Spark
        SparkConf conf = new SparkConf().setAppName("TerzoElementoRDD").setMaster("local[*]");

        // Creare un contesto Spark
        JavaSparkContext sc = new JavaSparkContext(conf);

        // Creare un elenco di dati
        List<String> dati = Arrays.asList("spark", "hadoop", "spark", "hive", "pig", "cassandra", "hadoop");

        // Creare un RDD da un elenco di dati
        JavaRDD<String> rdd = sc.parallelize(dati);

        // Ottenere il terzo elemento dell'RDD
        String terzoElemento = rdd.take(3).get(2);

        // Stampare il terzo elemento
        System.out.println("Il terzo elemento dell'RDD è: " + terzoElemento);

        // Fermare il contesto Spark
        sc.stop();
    }
}
