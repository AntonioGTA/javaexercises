package org.example.rdd;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import scala.Tuple2;

public class AirportUpperCase {
    public static void main(String[] args) {

        SparkConf conf = new SparkConf().setAppName("AirportUpperCaseProblem").setMaster("local[*]");
        JavaSparkContext sc = new JavaSparkContext(conf);


        JavaRDD<String> lines = sc.textFile("in/airports.text");


        JavaPairRDD<String, String> airportCountryPairRDD = lines.mapToPair(line -> {
            String[] parts = line.split(",");
            String airportName = parts[1];
            String countryName = parts[3];
            return new Tuple2<>(airportName, countryName);
        });


        JavaPairRDD<String, String> uppercaseAirportCountryPairRDD = airportCountryPairRDD.mapValues(countryName -> countryName.toUpperCase());


        uppercaseAirportCountryPairRDD.saveAsTextFile("out/airports_uppercase.text");

        sc.close();
    }
}

