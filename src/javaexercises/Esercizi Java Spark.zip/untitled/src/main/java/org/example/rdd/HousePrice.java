package org.example.rdd;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.*;

import java.util.Arrays;

public class HousePrice {
    public static void main(String[] args) {

        SparkSession spark = SparkSession.builder()
                .appName("HousePrice")
                .master("local[*]")
                .getOrCreate();


        Dataset<Row> data = spark.read().option("header", true).csv("in/RealEstate.csv");


        Dataset<Row> result = data.groupBy("Location")
                .agg(org.apache.spark.sql.functions.avg("Price SQ Ft").as("avg(Price SQ Ft)"),
                        org.apache.spark.sql.functions.max("Price").as("max(Price)"))
                .orderBy(org.apache.spark.sql.functions.col("avg(Price SQ Ft)").desc());


        result.show();


        spark.stop();
    }
}

