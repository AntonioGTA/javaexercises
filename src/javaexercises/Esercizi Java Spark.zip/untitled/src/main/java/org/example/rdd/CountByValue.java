package org.example.rdd;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class CountByValue {

    public static void main(String[] args) {
        // Creare una configurazione Spark
        SparkConf conf = new SparkConf().setAppName("ConteggioPerValore").setMaster("local[*]");

        // Creare un contesto Spark
        JavaSparkContext sc = new JavaSparkContext(conf);

        // Creare un elenco di dati
        List<String> dati = Arrays.asList("spark", "hadoop", "spark", "hive", "pig", "cassandra", "hadoop");

        // Creare un RDD da un elenco di dati
        JavaRDD<String> rdd = sc.parallelize(dati);

        // Contare il numero di occorrenze di ciascun elemento nell'RDD
        Map<String, Long> conteggioPerValore = rdd.countByValue();

        // Stampare la lista di conteggio
        System.out.println("Lista di conteggio per valore:");
        for (Map.Entry<String, Long> entry : conteggioPerValore.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        // Fermare il contesto Spark
        sc.stop();
    }
}
