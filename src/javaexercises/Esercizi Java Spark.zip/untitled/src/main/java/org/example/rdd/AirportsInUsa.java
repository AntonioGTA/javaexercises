package org.example.rdd;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import scala.Tuple2;

import java.util.Arrays;

public class AirportsInUsa {
    public static void main(String[] args) {

        JavaSparkContext sc = new JavaSparkContext("local[*]", "AirportsInUsa");


        JavaRDD<String> lines = sc.textFile("C:\\Users\\bb\\Downloads\\ESERCIZI\\untitled\\in\\airports.text");


        JavaRDD<String> airportsInUsa = lines.filter(line -> line.split(",")[3].equalsIgnoreCase("\"United States\""));


        JavaPairRDD<String, String> airportCityPairs = airportsInUsa.mapToPair(line -> {
            String[] parts = line.split(",");
            String airportName = parts[1].replaceAll("\"", "");
            String cityName = parts[2].replaceAll("\"", "");
            return new Tuple2<>(airportName, cityName);
        });


        airportCityPairs.map(pair -> "\"" + pair._1() + "\", \"" + pair._2() + "\"")
                .coalesce(1)
                .saveAsTextFile("out/airports_in_usaa.text");
        sc.close();
    }
}
