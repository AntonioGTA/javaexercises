package org.example.rdd;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import java.util.Arrays;
import java.util.List;

public class CollectJob {

public static void main(String[] args) {
        // Configurazione di Spark
        SparkConf conf = new SparkConf().setAppName("RDDList").setMaster("local[*]");
        JavaSparkContext sc = new JavaSparkContext(conf);

        // Lista di dati
        List<String> data = Arrays.asList("spark", "hadoop", "spark", "hive", "pig", "cassandra", "hadoop");


        JavaRDD<String> rdd = sc.parallelize(data);


        List<String> resultList = rdd.collect();

        System.out.println("Lista risultante:");
        for (String element : resultList) {
            System.out.println(element);
        }

        sc.close();
    }
}
