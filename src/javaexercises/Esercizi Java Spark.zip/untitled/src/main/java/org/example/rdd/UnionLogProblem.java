package org.example.rdd;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import java.util.Arrays;

public class UnionLogProblem {
    public static void main(String[] args) {

        SparkConf conf = new SparkConf().setAppName("UnionLogProblem").setMaster("local");
        JavaSparkContext sc = new JavaSparkContext(conf);


        JavaRDD<String> julyLogs = sc.textFile("C:\\Users\\bb\\Downloads\\ESERCIZI\\untitled\\in\\nasa_19950701.tsv").filter(line -> !line.startsWith("host"));
        JavaRDD<String> augustLogs = sc.textFile("C:\\Users\\bb\\Downloads\\ESERCIZI\\untitled\\in\\/nasa_19950801.tsv").filter(line -> !line.startsWith("host"));


        JavaRDD<String> combinedLogs = julyLogs.union(augustLogs);


        JavaRDD<String> sampledLogs = combinedLogs.sample(false, 0.001);


        sampledLogs.saveAsTextFile("C:\\Users\\bb\\Downloads\\ESERCIZI\\untitled\\out\\sample_nasa_logs.tsv");

        sc.close();
    }
}
