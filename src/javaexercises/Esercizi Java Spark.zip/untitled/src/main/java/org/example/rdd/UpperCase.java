package org.example.rdd;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

public class UpperCase {
    public static void main(String[] args) {
        // Create a SparkContext
        JavaSparkContext sparkContext = new JavaSparkContext("local[*]", "Uppercase");

        // Load the input file
        JavaRDD<String> lines = sparkContext.textFile("C:\\Users\\bb\\Downloads\\ESERCIZI\\untitled\\in\\uppercase.text");

        JavaRDD<String> uppercaseLines = lines.map(String::toUpperCase);

        uppercaseLines.saveAsTextFile("out/uppercase.text");

        sparkContext.stop();
    }
}
